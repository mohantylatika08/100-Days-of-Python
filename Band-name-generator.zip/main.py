print("Welcome to the Band Name Generator")
city= input("Which city did you grow up in?\n")
pet= input("Which is your favourite animal?\n")
print("Your band name could be: "+ city + " " + pet + "s")
